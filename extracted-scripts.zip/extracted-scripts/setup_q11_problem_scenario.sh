#!/bin/bash
# ============================================================
# CKS Practice | Q11: Hardening ServiceAccount Token Usage
# Creates namespace, ServiceAccount and Deployment
# Run on: controlplane node
# ============================================================

set -euo pipefail

NAMESPACE="serviceaccount"
MANIFEST_DIR="$HOME/monitor"
MANIFEST_FILE="$MANIFEST_DIR/deployment.yaml"

echo ""
echo "==========================================="
echo " CKS Q11 — Setting up ServiceAccount scenario..."
echo "==========================================="
echo ""

# ── Step 1: Reset only user-modified state ───────────────────
echo "[1/4] Cleaning up previous Q11 state..."

# Deployment — user modifies this (automountServiceAccountToken)
kubectl delete deployment monitor -n "$NAMESPACE" --ignore-not-found

# ServiceAccount — user modifies this (automountServiceAccountToken)
kubectl delete serviceaccount monitor-sa -n "$NAMESPACE" --ignore-not-found

# Manifest dir — always restore to original non-hardened version
rm -rf "$MANIFEST_DIR"

echo "  Previous state cleaned."

# ── Step 2: Ensure namespace exists ──────────────────────────
echo "[2/4] Checking namespace..."

if kubectl get namespace "$NAMESPACE" &>/dev/null; then
    echo "  Namespace '$NAMESPACE' already exists — skipping."
else
    kubectl create namespace "$NAMESPACE"
    echo "  Namespace '$NAMESPACE' created."
fi

# ── Step 3: Create ServiceAccount ────────────────────────────
echo "[3/4] Creating ServiceAccount monitor-sa..."

kubectl apply -f - <<EOF
apiVersion: v1
kind: ServiceAccount
metadata:
  name: monitor-sa
  namespace: $NAMESPACE
EOF

echo "  ServiceAccount monitor-sa created (automount: default true)."

# ── Step 4: Create manifest + apply Deployment ───────────────
echo "[4/4] Creating deployment manifest and applying..."

mkdir -p "$MANIFEST_DIR"

cat > "$MANIFEST_FILE" <<'EOF'
apiVersion: apps/v1
kind: Deployment
metadata:
  name: monitor
  namespace: serviceaccount
spec:
  replicas: 1
  selector:
    matchLabels:
      app: monitor
  template:
    metadata:
      labels:
        app: monitor
    spec:
      serviceAccountName: monitor-sa
      containers:
      - name: monitor
        image: nginx
        ports:
        - containerPort: 80
EOF

kubectl apply -f "$MANIFEST_FILE"

echo "  Waiting for deployment to be Ready..."
kubectl wait --for=condition=available deployment/monitor \
    -n "$NAMESPACE" --timeout=120s

echo ""
echo "✅ Q11 scenario is ready!"
echo ""
echo "Start the Solution!"
echo ""
